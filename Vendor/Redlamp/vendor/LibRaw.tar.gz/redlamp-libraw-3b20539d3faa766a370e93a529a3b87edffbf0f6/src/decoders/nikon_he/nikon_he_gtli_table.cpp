/* -*- C++ -*-
 * File: nikon_he_gtli_table.cpp
 * Copyright (C) 2026 Dmitri Sotnikov
 *
   Nikon HE GTLI (greatest truncatable level info) lookup table

LibRaw is free software; you can redistribute it and/or modify
it under the terms of the one of two licenses as you choose:

1. GNU LESSER GENERAL PUBLIC LICENSE version 2.1
   (See file LICENSE.LGPL provided in LibRaw distribution archive for details).

2. COMMON DEVELOPMENT AND DISTRIBUTION LICENSE (CDDL) Version 1.0
   (See file LICENSE.CDDL provided in LibRaw distribution archive for details).

 */

// Nikon HE GTLI lookup table — implementation.
//
// The table is indexed by (Bp, Br) → 26 sub-band GTLI values.
// Each row covers sub-bands 0..25 in this layout:
//   sb 0..5:   pass A wavelet horizontals, deepest 6 bands (LB 0)
//   sb 6..11:  pass A wavelet horizontals, next 6 bands (LB 1)
//   sb 12:     pass A LL band (LB 2)
//   sb 13..18: pass A wavelet horizontals, final 6 bands (LB 3)
//   sb 19..20: pass B wavelet horizontals, first 2 (LB 4)
//   sb 21..22: pass B wavelet horizontals, next 2 (LB 5)
//   sb 23:     pass B LL band (LB 6)
//   sb 24..25: pass B wavelet horizontals, final 2 (LB 7)

#include "nikon_he_gtli_table.h"
#include "nikon_he_picture_header.h"
#include <cstring>

namespace nikon_he {

namespace {

// One (Bp, Br) table entry.
struct GtliRow {
    int Bp;
    int Br;
    uint8_t values[kSubBandsPerPrecinct];
};

// All known (Bp, Br) → GTLI mappings. Keep sorted by (Bp, Br) for
// readability; the lookup does a linear scan (table has only ~20 rows).
const GtliRow kGtliTable[] = {
    // Bp=4 rows
    {4, 0,  {1,1,2,2,3,3, 2,3,3,4,4,4, 4, 2,3,3,4,4,4, 3,4, 4,4, 4, 4,4}},
    {4, 1,  {1,1,2,2,3,3, 2,3,3,4,4,4, 4, 2,3,3,3,4,4, 3,4, 4,4, 4, 4,4}},
    {4, 2,  {1,1,2,2,3,3, 2,3,3,3,4,4, 4, 2,3,3,3,4,4, 3,4, 4,4, 4, 4,4}},
    {4, 3,  {0,1,2,2,3,3, 2,3,3,3,4,4, 4, 2,3,3,3,4,4, 3,4, 4,4, 4, 4,4}},
    {4, 4,  {0,1,2,2,3,3, 2,2,3,3,4,4, 4, 2,3,3,3,4,4, 3,4, 4,4, 4, 4,4}},
    {4, 5,  {0,1,2,2,3,3, 2,2,3,3,4,4, 4, 2,2,3,3,4,4, 3,4, 4,4, 4, 4,4}},
    {4, 6,  {0,1,2,2,3,3, 1,2,3,3,4,4, 4, 2,2,3,3,4,4, 3,4, 4,4, 4, 4,4}},
    {4, 7,  {0,1,2,2,3,3, 1,2,3,3,4,4, 4, 1,2,3,3,4,4, 3,4, 4,4, 4, 4,4}},
    {4,11,  {0,1,1,2,2,3, 1,2,3,3,3,4, 4, 1,2,3,3,3,4, 3,4, 4,4, 4, 4,4}},
    {4,12,  {0,1,1,2,2,3, 1,2,3,3,3,4, 3, 1,2,3,3,3,4, 3,4, 4,4, 3, 4,4}},
    // Bp=5 rows
    {5,12,  {1,2,2,3,3,4, 2,3,4,4,4,5, 4, 2,3,4,4,4,5, 4,5, 5,5, 4, 5,5}},
    {5,13,  {1,2,2,3,3,4, 2,3,4,4,4,5, 4, 2,3,4,4,4,5, 4,5, 5,5, 4, 4,5}},
    {5,14,  {1,2,2,3,3,4, 2,3,4,4,4,4, 4, 2,3,4,4,4,5, 4,5, 5,5, 4, 4,5}},
    {5,15,  {1,2,2,3,3,4, 2,3,4,4,4,4, 4, 2,3,4,4,4,4, 4,5, 5,5, 4, 4,5}},
    {5,16,  {1,2,2,3,3,4, 2,3,4,4,4,4, 4, 2,3,4,4,4,4, 4,5, 4,5, 4, 4,5}},
    {5,20,  {1,1,2,3,3,4, 2,3,3,4,4,4, 4, 2,3,3,4,4,4, 4,4, 4,5, 4, 4,5}},
    {5,21,  {1,1,2,3,3,4, 2,3,3,4,4,4, 4, 2,3,3,4,4,4, 3,4, 4,5, 4, 4,5}},
    {5,22,  {1,1,2,3,3,3, 2,3,3,4,4,4, 4, 2,3,3,4,4,4, 3,4, 4,5, 4, 4,5}},
    {5,23,  {1,1,2,2,3,3, 2,3,3,4,4,4, 4, 2,3,3,4,4,4, 3,4, 4,5, 4, 4,5}},
    {5,24,  {1,1,2,2,3,3, 2,3,3,4,4,4, 4, 2,3,3,4,4,4, 3,4, 4,4, 4, 4,5}},

    // HE* (Lossy_High_Efficiency_Star) rows. Captured 2026-05-22 from
    // raw.pixls.us "Lossy_High_Efficiency_Star" sample. 38 unique
    // (Bp, Br) combos, all gtli-consistent across precincts.
    {1,  0, {0,0,0,0,0,0, 0,0,0,1,1,1, 1, 0,0,0,1,1,1, 0,1, 1,1, 1, 1,1}},
    {1,  1, {0,0,0,0,0,0, 0,0,0,1,1,1, 1, 0,0,0,0,1,1, 0,1, 1,1, 1, 1,1}},
    {1,  7, {0,0,0,0,0,0, 0,0,0,0,1,1, 1, 0,0,0,0,1,1, 0,1, 1,1, 1, 1,1}},
    {1,  8, {0,0,0,0,0,0, 0,0,0,0,0,1, 1, 0,0,0,0,1,1, 0,1, 1,1, 1, 1,1}},
    {1, 11, {0,0,0,0,0,0, 0,0,0,0,0,1, 1, 0,0,0,0,0,1, 0,1, 1,1, 1, 1,1}},
    {2,  0, {0,0,0,1,1,2, 0,1,1,2,2,2, 2, 0,1,1,2,2,2, 1,2, 2,2, 2, 2,2}},
    {2,  1, {0,0,0,1,1,2, 0,1,1,2,2,2, 2, 0,0,1,1,2,2, 1,2, 2,2, 2, 2,2}},
    {2,  3, {0,0,0,0,1,1, 0,1,1,2,2,2, 2, 0,0,1,1,2,2, 1,2, 2,2, 2, 2,2}},
    {2,  4, {0,0,0,0,1,1, 0,0,1,1,2,2, 2, 0,0,1,1,2,2, 1,2, 2,2, 2, 2,2}},
    {2,  7, {0,0,0,0,1,1, 0,0,1,1,2,2, 2, 0,0,1,1,1,2, 1,2, 2,2, 2, 2,2}},
    {2,  8, {0,0,0,0,0,1, 0,0,1,1,2,2, 2, 0,0,1,1,1,2, 1,2, 2,2, 2, 2,2}},
    {2, 10, {0,0,0,0,1,1, 0,0,1,1,1,2, 2, 0,0,1,1,1,2, 1,2, 2,2, 2, 2,2}},
    {2, 11, {0,0,0,0,0,1, 0,0,1,1,1,2, 2, 0,0,1,1,1,2, 1,2, 2,2, 2, 2,2}},
    {2, 12, {0,0,0,0,0,1, 0,0,1,1,1,2, 1, 0,0,1,1,1,2, 1,2, 2,2, 1, 2,2}},
    {2, 13, {0,0,0,0,0,1, 0,0,1,1,1,2, 1, 0,0,1,1,1,2, 1,2, 2,2, 1, 1,2}},
    {2, 14, {0,0,0,0,0,1, 0,0,1,1,1,1, 1, 0,0,1,1,1,2, 1,2, 2,2, 1, 1,2}},
    {2, 15, {0,0,0,0,0,1, 0,0,1,1,1,1, 1, 0,0,1,1,1,1, 1,2, 2,2, 1, 1,2}},
    {2, 16, {0,0,0,0,0,1, 0,0,1,1,1,1, 1, 0,0,1,1,1,1, 1,2, 1,2, 1, 1,2}},
    {2, 17, {0,0,0,0,0,1, 0,0,1,1,1,1, 1, 0,0,0,1,1,1, 1,2, 1,2, 1, 1,2}},
    {2, 18, {0,0,0,0,0,1, 0,0,0,1,1,1, 1, 0,0,0,1,1,1, 1,2, 1,2, 1, 1,2}},
    {2, 20, {0,0,0,0,0,1, 0,0,0,1,1,1, 1, 0,0,0,1,1,1, 1,1, 1,2, 1, 1,2}},
    {2, 21, {0,0,0,0,0,1, 0,0,0,1,1,1, 1, 0,0,0,1,1,1, 0,1, 1,2, 1, 1,2}},
    {2, 23, {0,0,0,0,0,0, 0,0,0,1,1,1, 1, 0,0,0,1,1,1, 0,1, 1,2, 1, 1,2}},
    {2, 24, {0,0,0,0,0,0, 0,0,0,1,1,1, 1, 0,0,0,1,1,1, 0,1, 1,1, 1, 1,2}},
    {3,  8, {0,0,1,1,2,2, 0,1,2,2,2,3, 3, 0,1,2,2,3,3, 2,3, 3,3, 3, 3,3}},
    {3, 11, {0,0,0,1,1,2, 0,1,2,2,2,3, 3, 0,1,2,2,2,3, 2,3, 3,3, 3, 3,3}},
    {3, 12, {0,0,0,1,1,2, 0,1,2,2,2,3, 2, 0,1,2,2,2,3, 2,3, 3,3, 2, 3,3}},
    {3, 13, {0,0,0,1,1,2, 0,1,2,2,2,3, 2, 0,1,2,2,2,3, 2,3, 3,3, 2, 2,3}},
    {3, 14, {0,0,0,1,1,2, 0,1,2,2,2,2, 2, 0,1,2,2,2,3, 2,3, 3,3, 2, 2,3}},
    {3, 15, {0,0,0,1,1,2, 0,1,2,2,2,2, 2, 0,1,2,2,2,2, 2,3, 3,3, 2, 2,3}},
    {3, 16, {0,0,0,1,1,2, 0,1,2,2,2,2, 2, 0,1,2,2,2,2, 2,3, 2,3, 2, 2,3}},
    {3, 17, {0,0,0,1,1,2, 0,1,2,2,2,2, 2, 0,1,1,2,2,2, 2,3, 2,3, 2, 2,3}},
    {3, 18, {0,0,0,1,1,2, 0,1,1,2,2,2, 2, 0,1,1,2,2,2, 2,3, 2,3, 2, 2,3}},
    {3, 20, {0,0,0,1,1,2, 0,1,1,2,2,2, 2, 0,1,1,2,2,2, 2,2, 2,3, 2, 2,3}},
    {3, 21, {0,0,0,1,1,2, 0,1,1,2,2,2, 2, 0,1,1,2,2,2, 1,2, 2,3, 2, 2,3}},
    {3, 22, {0,0,0,1,1,1, 0,1,1,2,2,2, 2, 0,1,1,2,2,2, 1,2, 2,3, 2, 2,3}},
    {3, 23, {0,0,0,0,1,1, 0,1,1,2,2,2, 2, 0,1,1,2,2,2, 1,2, 2,3, 2, 2,3}},
    {3, 24, {0,0,0,0,1,1, 0,1,1,2,2,2, 2, 0,1,1,2,2,2, 1,2, 2,2, 2, 2,3}},
};

constexpr int kNumGtliRows = sizeof(kGtliTable) / sizeof(kGtliTable[0]);

}  // namespace

// The decoder indexes 26 sub-bands while WGT declares 25. Sub-band 23 is the
// pass-B LL band and shares the entry of sub-band 12, the pass-A LL band.
namespace {

thread_local const nikon_he::PictureHeader* g_picture_header = nullptr;

constexpr int kPassA_LL_Band = 12;
constexpr int kPassB_LL_Band = 23;

inline int wgt_index_for_band(int b) {
    if (b < kPassB_LL_Band)  return b;
    if (b == kPassB_LL_Band) return kPassA_LL_Band;
    return b - 1;
}

}  // namespace

void set_active_picture_header(const PictureHeader* ph) {
    g_picture_header = ph;
}

const uint8_t* lookup_gtli_table(int Bp, int Br) {
    const PictureHeader* ph = g_picture_header;
    if (ph && ph->valid && ph->nbands > 0) {
        static thread_local uint8_t computed[kSubBandsPerPrecinct];
        for (int b = 0; b < kSubBandsPerPrecinct; ++b) {
            const int w = wgt_index_for_band(b);
            computed[b] = (uint8_t)gtli_from_weights(*ph, w, Bp, Br);
        }
        return computed;
    }

    for (int i = 0; i < kNumGtliRows; ++i) {
        if (kGtliTable[i].Bp == Bp && kGtliTable[i].Br == Br) {
            return kGtliTable[i].values;
        }
    }
    return nullptr;
}

}  // namespace nikon_he
